<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Geeklog Forums Plugin 2.8.0                                               |
// +---------------------------------------------------------------------------+
// | gf_format.php                                                             |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2011 by the following authors:                              |
// |    Geeklog Community Members   geeklog-forum AT googlegroups DOT com      |
// |                                                                           |
// | Copyright (C) 2000,2001,2002,2003 by the following authors:               |
// |    Tony Bibbs       tony AT tonybibbs DOT com                             |
// |                                                                           |
// | Forum Plugin Authors                                                      |
// |    Mr.GxBlock                                        www.gxblock.com      |
// |    Matthew DeWyer   matt AT mycws DOT com            www.cweb.ws          |
// |    Blaine Lang      geeklog AT langfamily DOT ca     www.langfamily.ca    |
// +---------------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU General Public License               |
// | as published by the Free Software Foundation; either version 2            |
// | of the License, or (at your option) any later version.                    |
// |                                                                           |
// | This program is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
// | GNU General Public License for more details.                              |
// |                                                                           |
// | You should have received a copy of the GNU General Public License         |
// | along with this program; if not, write to the Free Software Foundation,   |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.           |
// +---------------------------------------------------------------------------+

// this file can't be used on its own
if (strpos(strtolower($_SERVER['PHP_SELF']), 'gf_format.php') !== false) {
    die ('This file can not be used on its own.');
}

if (!class_exists('StringParser') ) {
    require_once $CONF_FORUM['path_include'] . 'bbcode/stringparser_bbcode.class.php';
}

function gf_createHTMLDocument(&$content = '', $subject = '', $noIndex = 0, $canonical_url = '') {
    global $CONF_FORUM, $LANG_GF01;

    // Display Common headers
    if (!isset($CONF_FORUM['showblocks'])) $CONF_FORUM['showblocks'] = 'leftblocks';
    if (!isset($CONF_FORUM['usermenu'])) $CONF_FORUM['usermenu'] = 'blockmenu';

    $information = array();
	// see if noindex or canonical url passed (can't have both)
    if ($noIndex) {
        $information['headercode'] = '<meta name="robots" content="noindex"' . XHTML . '>';
    } else {
		if (!empty($canonical_url)) {
			$information['headercode'] = '<link rel="canonical" href="' . $canonical_url . '"' . XHTML . '>';		
		}
	}
	
    if ($subject != '') {
        $information['pagetitle'] = $subject;
    } else {
        $information['pagetitle'] = $LANG_GF01['FORUM'];
    }
    $information['what'] = 'menu';
    $information['rightblock'] = false;

    if ($CONF_FORUM['showblocks'] == 'noblocks' OR $CONF_FORUM['showblocks'] == 'rightblocks') {
        $information['what'] = 'none';
    } elseif ($CONF_FORUM['showblocks'] == 'leftblocks' OR $CONF_FORUM['showblocks'] == 'allblocks') {
        if ($CONF_FORUM['usermenu'] == 'blockmenu') {
            $CONF_FORUM['add_forum_menu_check'] = 1;
        }
    }

    if ($CONF_FORUM['showblocks'] == 'rightblocks') {
        $information['rightblock'] = true;
        if ($CONF_FORUM['usermenu'] == 'blockmenu') {
            $CONF_FORUM['add_forum_menu_check'] = 1;
        }
    } elseif ($CONF_FORUM['showblocks'] == 'allblocks') {
        $information['rightblock'] = true;
    }

    return COM_createHTMLDocument($content, $information);
}

function convertlinebreaks ($text) {
    return preg_replace ("/\015\012|\015|\012/", "\n", $text);
}

function bbcode_stripcontents ($text) {
    return preg_replace ("/[^\n]/", '', $text);
}

function bbcode_htmlspecialchars($text) {
    global $CONF_FORUM;

    return (htmlspecialchars ($text,ENT_QUOTES, $CONF_FORUM['charset']));
}

function gf_fixtemplate($text) {
    $text = str_replace('{','&#123;',$text);
    $text = str_replace('}','&#125;',$text);

    return $text;
}

function do_bbcode_url($action, $attributes, $content, $params, $node_object)
{
    global $_CONF, $CONF_FORUM;

    if ($action == 'validate') {
        return true;
    }

    $href = isset($attributes['default']) && $attributes['default'] !== ''
        ? strip_tags($attributes['default'])
        : $content;

    if (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $href)) {
        $href = 'http://' . $href;
    }

    $siteHost = parse_url($_CONF['site_url'], PHP_URL_HOST);
    $linkHost = parse_url($href, PHP_URL_HOST);
    $isInternal = $siteHost && $linkHost
        && strcasecmp($siteHost, $linkHost) === 0;

    $label = isset($attributes['default']) && $attributes['default'] !== ''
        ? $content
        : htmlspecialchars($content, ENT_QUOTES, $CONF_FORUM['charset']);

    if ($isInternal) {
        return '<a href="' . htmlspecialchars($href, ENT_QUOTES, $CONF_FORUM['charset']) . '">'
            . $label . '</a>';
    }

    return '<a href="' . htmlspecialchars($href, ENT_QUOTES, $CONF_FORUM['charset'])
        . '" target="_blank" rel="nofollow noopener noreferrer">' . $label . '</a>';
}

function do_bbcode_list ($action, $attributes, $content, $params, $node_object) {
    if ($action == 'validate') {
        return true;
    }
    if (!isset ($attributes['default'])) {
        return '<ul>'.$content.'</ul>';
    } else {
        if ( is_numeric($attributes['default']) ) {
            return '<ol>'.$content.'</ol>';
        } else {
            return '<ul>'.$content.'</ul>';
        }
    }
    return '<ul>'.$content.'</ul>';
}


function do_bbcode_img ($action, $attributes, $content, $params, $node_object) {
    global $CONF_FORUM;

    if ($action == 'validate') {
        if (isset($attributes['caption'])) {
            $node_object->setFlag('paragraph_type', BBCODE_PARAGRAPH_BLOCK_ELEMENT);
            if ($node_object->_parent->type() == STRINGPARSER_NODE_ROOT OR
                in_array($node_object->_parent->_codeInfo['content_type'], array('block', 'list', 'listitem'))) {
                return true;
            }
            else return false;
        }
        else return true;
    }

    if ($CONF_FORUM['allow_img_bbcode']) {
        if ( isset($attributes['h']) AND isset ($attributes['w']) ) {
            $dim = 'width="' . COM_applyFilter($attributes['w'], true) . '" height="' . COM_applyFilter($attributes['h'], true) . '" ';
        } else {
            $dim = '';
        }
        if ( isset($attributes['align'] ) ) {
            $align = ' align="' . COM_applyFilter($attributes['align']) . '" ';
        } else {
            $align = '';
        }

        return '<img src="'.htmlspecialchars($content,ENT_QUOTES, $CONF_FORUM['charset']).'" ' . $dim . $align . 'alt=""'. XHTML .'>';
    } else {
        return '[img]' . $content . '[/img]';
    }
}

function do_bbcode_size  ($action, $attributes, $content, $params, $node_object) {
    if ( $action == 'validate') {
        return true;
    }
    return '<span style="font-size: '.COM_applyFilter($attributes['default'], true).'px;">'.$content.'</span>';
}

function do_bbcode_color  ($action, $attributes, $content, $params, $node_object) {
    if ( $action == 'validate') {
        return true;
    }
	if (!isset ($attributes['default'])) {
		return $content;
	}
	
    return '<span style="color: '.COM_applyFilter($attributes['default']).';">'.$content.'</span>';
}

function do_bbcode_code($action, $attributes, $content, $params, $node_object) {
    global $CONF_FORUM, $oldPost;

    if ( $action == 'validate') {
        return true;
    }

    if ( $oldPost ) {
        $content = str_replace("&#36;","$", $content);
        $content = html_entity_decode($content);
    }

    if ($CONF_FORUM['allow_smilies']) {
        if (function_exists('msg_restoreEmoticons') AND $CONF_FORUM['use_smilies_plugin']) {
            $content = msg_restoreEmoticons($content);
        } else {
            $content = forum_xchsmilies($content,true);
        }
    }
    if ($CONF_FORUM['use_geshi']) {
        /* Support for formatting various code types : [code=java] for example */
        if (!isset ($attributes['default'])) {
            $codeblock = geshi_formatted($content);
        } else {
            $codeblock = geshi_formatted($content,strtoupper(COM_applyFilter($attributes['default'])));
        }
    } else {
        $codeblock = '<pre class="codeblock">'  . htmlspecialchars($content,ENT_QUOTES, $CONF_FORUM['charset']) . '</pre>';
    }
    $codeblock = str_replace('{','&#123;',$codeblock);
    $codeblock = str_replace('}','&#125;',$codeblock);

    return $codeblock;
}

// Category and Forum must already be filtered and permissions checked
function forumNavbarMenu($current = '', $category = '', $forum = '') {
    global $_CONF, $CONF_FORUM, $_USER, $LANG_GF01, $LANG_GF02;

	$urlVariable = '';
	if (!empty($forum)) {
		$urlVariable = "&amp;forum=$forum";
		$delMessage = $LANG_GF02['msg302'];
	} elseif (!empty($category)) {
		$urlVariable = "&amp;category=$category";
		$delMessage = $LANG_GF02['msg303'];
	} else {
		$delMessage = $LANG_GF02['msg301'];
	}

    require_once $_CONF['path_system'] . 'classes/navbar.class.php';
    $navmenu = new navbar; 
    $navmenu->add_menuitem($LANG_GF01['INDEXPAGE'],"{$_CONF['site_url']}/forum/index.php");
    $navmenu->set_onclick($LANG_GF01['INDEXPAGE'], 'location.href="' . "{$_CONF['site_url']}/forum/index.php" . '";'); // Added as a fix for the navbar class (since uikit tabs do not support urls)
    if (!COM_isAnonUser()) {  
        $navmenu->add_menuitem($LANG_GF02['msg197'],"{$_CONF['site_url']}/forum/index.php?op=markallread$urlVariable");
        // Added as a fix for the navbar class (since uikit tabs do not support urls)
        //$navmenu->set_onclick($LANG_GF02['msg197'], 'return confirm("' . $LANG_GF02['msg301'] . '");');
        $navmenu->set_onclick($LANG_GF02['msg197'], '
          if (confirm("' . $delMessage . '")) {
            window.location.href="' . "{$_CONF['site_url']}/forum/index.php?op=markallread$urlVariable" . '";
          }
          return false;        
        ');
        $navmenu->add_menuitem($LANG_GF01['USERPREFS'],"{$_CONF['site_url']}/forum/userprefs.php");
        $navmenu->set_onclick($LANG_GF01['USERPREFS'], 'location.href="' . "{$_CONF['site_url']}/forum/userprefs.php" . '";'); // Added as a fix for the navbar class (since uikit tabs do not support urls)
        $navmenu->add_menuitem($LANG_GF01['SUBSCRIPTIONS'],"{$_CONF['site_url']}/forum/notify.php");
        $navmenu->set_onclick($LANG_GF01['SUBSCRIPTIONS'], 'location.href="' . "{$_CONF['site_url']}/forum/notify.php" . '";'); // Added as a fix for the navbar class (since uikit tabs do not support urls)
    }
    if (($CONF_FORUM['show_memberslist_anonymous'] && COM_isAnonUser()) OR !COM_isAnonUser()) {
    	$navmenu->add_menuitem($LANG_GF02['msg200'],"{$_CONF['site_url']}/forum/memberlist.php");
        $navmenu->set_onclick($LANG_GF02['msg200'], 'location.href="' . "{$_CONF['site_url']}/forum/memberlist.php" . '";'); // Added as a fix for the navbar class (since uikit tabs do not support urls)
	}
    $navmenu->add_menuitem($LANG_GF02['msg201'],"{$_CONF['site_url']}/forum/index.php?op=popular");
    $navmenu->set_onclick($LANG_GF02['msg201'], 'location.href="' . "{$_CONF['site_url']}/forum/index.php?op=popular" . '";'); // Added as a fix for the navbar class (since uikit tabs do not support urls)
    if ($current != '') {
        $navmenu->set_selected($current);
    }
    return $navmenu->generate();
}

// Category and Forum must be filtered and permissions already checked. Can be empty
function ForumHeader($category, $forum, $showtopic, &$display) {
    global $_TABLES, $_CONF, $CONF_FORUM, $LANG_GF01, $LANG_GF02;
    
    $navbar = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $navbar->set_file (array ('topicheader'=>'navbar.thtml'));
    $navbar->set_var ('search_forum', f_forumsearch());
    $navbar->set_var ('select_forum', f_forumjump());
    if ($CONF_FORUM['usermenu'] == 'navbar') {
        if (empty($forum)) {
            $navbar->set_var('navmenu', forumNavbarMenu($LANG_GF01['INDEXPAGE'], $category, $forum));
        } else {
            $navbar->set_var('navmenu', forumNavbarMenu('', $category, $forum));
        }
    } else {
        $navbar->set_var('navmenu','');
    }
    
    $navbar->set_var('block_start', COM_startBlock($CONF_FORUM['forums_name']));
    
    $navbar->parse ('output', 'topicheader');
    $display .= $navbar->finish($navbar->get_var('output'));
}

function gf_checkHTMLforSQL($str,$postmode='html') {
    global $CONF_FORUM;

    $bbcode = new StringParser_BBCode ();
    $bbcode->setGlobalCaseSensitive (false);
    // It is impossible to include block level elements in a <p> element. Therefore I fix this.
    $bbcode->setParagraphHandlingParameters ("\n\n", "", "");

    if ( $CONF_FORUM['use_glfilter'] == 1 && ($postmode == 'html' || $postmode == 'HTML')) {
        $bbcode->addParser(array('block','inline'), 'gf_cleanHTML');
    }
    $bbcode->addCode ('code', 'simple_replace', null, array ('start_tag' => '[code]', 'end_tag' => '[/code]'),
                      'code', array ('listitem', 'block', 'inline', 'link'), array ());
    $str = $bbcode->parse ($str);
    return $str;
}

/**
* Cleans (filters) HTML - only allows HTML tags specified in the
* $_CONF['user_html'] string.  This function is designed to be called
* by the stringparser class to filter everything except [code] blocks.
*
* @param        string      $message        The topic post to filter
* @return       string      filtered HTML code
*/
function gf_cleanHTML($message) {
    global $_CONF, $CONF_FORUM;

    if ( isset( $_CONF['skip_html_filter_for_root'] ) &&
             ( $_CONF['skip_html_filter_for_root'] == 1 ) &&
            SEC_inGroup( 'Root' ))
    {
        return $message;
    }
    
    // If user has story edit privileges then can use html allowed by admins
    return gf_htmLawed($message, 'story.edit');
    
}


function gf_preparefordb($message,$postmode) {
    global $CONF_FORUM, $_CONF;

    // if magic quotes is on, remove the slashes from the $_POST
    //if (get_magic_quotes_gpc() ) {
    //   $message = stripslashes($message);
    //}
    
    // Remove any autotags the user doesn't have permission to use
    $message = PLG_replaceTags($message, '', true);    
    
    // Remove Icons if database cannot store them (ie table collation needs to be utf8mb4)
    $message = GLText::remove4byteUtf8Chars($message);

    if ( $CONF_FORUM['use_glfilter'] == 1 && ($postmode == 'html' || $postmode == 'HTML') ) {
        $message = gf_checkHTMLforSQL($message,$postmode);
    }

    if ($CONF_FORUM['use_censor']) {
        $message = COM_checkWords($message);
    }
    $message = addslashes($message);
    return $message;
}

function geshi_formatted($str,$type='Text') {
    global $_CONF, $CONF_FORUM;

    include_once 'geshi.php';

    $geshi = new Geshi($str, $type, "{$CONF_FORUM['path_include']}geshi");
	if (!$geshi->error()) { // Make Sure Type Exists
		$geshi->set_header_type(GESHI_HEADER_DIV);
		//$geshi->enable_strict_mode(true);
		//$geshi->enable_classes();
		$geshi->enable_line_numbers(GESHI_NO_LINE_NUMBERS, 5);
		$geshi->set_overall_class('glforum-code');
		//$geshi->set_overall_style('font-size: 12px; color: #000066; border: 1px solid #d0d0d0; background-color: #FAFAFA;', true);
		//// Note the use of set_code_style to revert colours...
		//$geshi->set_line_style('font: normal normal 95% \'Courier New\', Courier, monospace; color: #003030;', 'font-weight: bold; color: #006060;', true);
		//$geshi->set_code_style('color: #000020;', 'color: #000020;');
		//$geshi->set_line_style('background: red;', true);
		//$geshi->set_link_styles(GESHI_LINK, 'color: #000060;');
		//$geshi->set_link_styles(GESHI_HOVER, 'background-color: #f0f000;');

		$geshi->set_header_content("$type Formatted Code");
		//$geshi->set_header_content_style('font-family: Verdana, Arial, sans-serif; color: #808080; font-size: 90%; font-weight: bold; background-color: #f0f0ff; border-bottom: 1px solid #d0d0d0; padding: 2px;');

		return $geshi->parse_code();
	} else {
		// Type / Code Language not found so fallback and return basic monospaced text code block (like when Geshi is not enabled) 
		return '<pre class="codeblock">'  . htmlspecialchars($str,ENT_QUOTES, $CONF_FORUM['charset']) . '</pre>';
	}
}

function gf_htmLawed($str, $permissions = '') {
    global $_CONF;

    // Sets config options for htmLawed.  See http://www.bioinformatics.org/
    // phplabware/internal_utilities/htmLawed/htmLawed_README.htm
    $config = array(
        'balance'        => 1, // Balance tags for well-formedness and proper nesting
        'comment'        => 3, // Allow HTML comment
        'css_expression' => 1, // Allow dynamic CSS expression in "style" attributes
//            'keep_bad'       => 1, // Neutralize both tags and element content
        'keep_bad'       => 0, // Neutralize both tags and element content
        'tidy'           => 0, // Don't beautify or compact HTML code
        'unique_ids'     => 1, // Remove duplicate and/or invalid ids
        'valid_xhtml'    => 1, // Magic parameter to make input the most valid XHTML
    );

    if (isset($_CONF['allowed_protocols']) &&
            is_array($_CONF['allowed_protocols']) &&
            (count($_CONF['allowed_protocols']) > 0)) {
        $schemes = $_CONF['allowed_protocols'];
    } else {
        $schemes = array('http:', 'https:', 'ftp:');
    }

    $schemes = str_replace(':', '', implode(', ', $schemes));
    $config['schemes'] = 'href: ' . $schemes . '; *: ' . $schemes;

    if (empty($permissions) || !SEC_hasRights($permissions) || empty($_CONF['admin_html'])) {
        $html = $_CONF['user_html'];
    } else {
        $html = array_merge_recursive($_CONF['user_html'], $_CONF['admin_html']);
    }

    foreach ($html as $tag => $attr) {
        if (is_array($attr) && (count($attr) > 0)) {
            $spec[] = $tag . '=' . implode(', ', array_keys($attr));
        } else {
            $spec[] = $tag . '=-*';
        }

        $elements[] = $tag;
    }

    $config['elements'] = implode(', ', $elements);
    $spec = implode('; ', $spec);
    $str = htmLawed($str, $config, $spec);

    return $str;
}

function gf_checkHTML($str) {
    global $CONF_FORUM, $_CONF;

    // just return if admin doesn't want to filter html
    if ( $CONF_FORUM['use_glfilter'] != 1 ) {
        return $str;
    }
    // if Geeklog is configured to allow root to use all html, no need to call
    if ( isset( $_CONF['skip_html_filter_for_root'] ) &&
             ( $_CONF['skip_html_filter_for_root'] == 1 ) &&
            SEC_inGroup( 'Root' ))
    {
        return $str;
    }
    
    // If user has story edit previlages then can use html allowed by admins
    return gf_htmLawed($str, 'story.edit');
}


/**
 * Escape Geeklog autotags inside Forum [code] blocks.
 *
 * Autotags outside code are protected separately and expanded after BBCode
 * parsing. Inside code they must stay literal, just like smilie symbols.
 *
 * @param string $str
 * @return string
 */
function gf_escapeAutotagsInCodeBlocks($str)
{
    return preg_replace_callback(
        '/(\\[code(?:=[^\\]]+)?\\])(.*?)(\\[\\/code\\])/is',
        function ($matches) {
            $body = preg_replace_callback(
                '/\\[([A-Za-z][A-Za-z0-9_-]*):([^\\]]+)\\]/',
                function ($tag) {
                    return '&#91;' . $tag[1] . ':' . $tag[2] . '&#93;';
                },
                $matches[2]
            );

            return $matches[1] . $body . $matches[3];
        },
        $str
    );
}

function gf_formatTextBlock($str,$postmode='html',$mode='') {
    global $CONF_FORUM;

    $bbcode = new StringParser_BBCode ();
    $bbcode->setGlobalCaseSensitive (false);
    // It is impossible to include block level elements in a <p> element. Therefore I fix this.
    $bbcode->setParagraphHandlingParameters ("\n\n", "", "");

    if ( $postmode == 'text') {
        $bbcode->addParser (array ('block', 'inline', 'link', 'listitem'), 'bbcode_htmlspecialchars');
    }

    // This filtering should only happen on save and preview and not when viewed in a topic.
    // If an Admin adds HTML that he can only use to a post, we then want ALL users to see it.
    if ( $CONF_FORUM['use_glfilter'] == 1 && $postmode == 'html' && $mode == 'preview') {
        $bbcode->addParser(array('block','inline','link','listitem'), 'gf_checkHTML');      // calls GL's checkHTML on all text blocks
    }
    
    if ( $postmode == 'text' OR $mode == 'subject') {
    	$bbcode->addParser(array('block','inline','link','listitem'), 'nl2br');
	}
    if ( $mode != 'subject' ) {
        $bbcode->addParser(array('block','inline','link','listitem'), 'gf_replacesmilie');      // calls replacesmilie on all text blocks
    }
    $bbcode->addParser(array('block','inline','link','listitem'), 'gf_fixtemplate');
    if ( $mode != 'subject' ) {
//        $bbcode->addParser(array('block','inline','link','listitem'), 'PLG_replacetags');
    }

	// Docs http://christian-seiler.de/projekte/php/bbcode/doc/en/chapter1.php

    $bbcode->addParser ('list', 'bbcode_stripcontents');
    $bbcode->addCode ('b', 'simple_replace', null, array ('start_tag' => '<b>', 'end_tag' => '</b>'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    $bbcode->addCode ('i', 'simple_replace', null, array ('start_tag' => '<i>', 'end_tag' => '</i>'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    $bbcode->addCode ('u', 'simple_replace', null, array ('start_tag' => '<span style="text-decoration: underline;">', 'end_tag' => '</span>'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    $bbcode->addCode ('p', 'simple_replace', null, array ('start_tag' => '<p>', 'end_tag' => '</p>'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    $bbcode->addCode ('br', 'simple_replace', null, array ('start_tag' => '<br' . XHTML . '>', 'end_tag' => ''),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    $bbcode->addCode ('s', 'simple_replace', null, array ('start_tag' => '<del>', 'end_tag' => '</del>'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
	// Below was 'usecontent?' but switched to 'callback_replace' since size always requires to be equal something ie [size=15] and we want the bbcode within the size tag to be parsed
    $bbcode->addCode ('size', 'callback_replace', 'do_bbcode_size', array ('usercontent_param' => 'default'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
	// Below was 'usecontent?' but switched to 'callback_replace' since color always requires to be equal something ie [color=red] and we want the bbcode within the size tag to be parsed
    $bbcode->addCode ('color', 'callback_replace', 'do_bbcode_color', array ('usercontent_param' => 'default'),
                      'inline', array ('listitem', 'block', 'inline', 'link'), array ());
    if ( $mode != 'subject' ) {                      
        $bbcode->addCode ('list', 'callback_replace', 'do_bbcode_list', array ('usecontent_param' => 'default'),
                          'list', array ('inline','block', 'listitem'), array ());
        $bbcode->addCode ('*', 'simple_replace', null, array ('start_tag' => '<li>', 'end_tag' => '</li>'),
                          'listitem', array ('list'), array ());
        $bbcode->addCode ('quote','simple_replace',null,array('start_tag' => '<div class="quotemain">', 'end_tag' => '</div>'),
                          'inline', array('listitem','block','inline','link'), array());                          
        $bbcode->addCode ('url', 'usecontent?', 'do_bbcode_url', array ('usecontent_param' => 'default'),
                          'link', array ('listitem', 'block', 'inline'), array ('link'));
        $bbcode->addCode ('link', 'callback_replace_single', 'do_bbcode_url', array (),
                          'link', array ('listitem', 'block', 'inline'), array ('link'));
        $bbcode->addCode ('img', 'usecontent', 'do_bbcode_img', array (),
                          'image', array ('listitem', 'block', 'inline', 'link'), array ());
        $bbcode->addCode ('code', 'usecontent', 'do_bbcode_code', array ('usecontent_param' => 'default'),
                          'code', array ('listitem', 'block', 'inline', 'link'), array ());
    }              
    $bbcode->setCodeFlag ('quote', 'paragraph_type', BBCODE_PARAGRAPH_ALLOW_INSIDE);
    $bbcode->setCodeFlag ('*', 'closetag', BBCODE_CLOSETAG_OPTIONAL);
    $bbcode->setCodeFlag ('*', 'paragraphs', true);
    $bbcode->setCodeFlag ('list', 'opentag.before.newline', BBCODE_NEWLINE_DROP);
    $bbcode->setCodeFlag ('list', 'closetag.before.newline', BBCODE_NEWLINE_DROP);

    $bbcode->setRootParagraphHandling (true);

    if ($mode == 'preview') {
        // Remove any autotags the user doesn't have permission to use from preview
        $str = PLG_replaceTags($str, '', true);     
    }    
    if ($CONF_FORUM['use_censor'] and $mode == 'preview') {
        $str = COM_checkWords($str);
    }

    // Autotags shown as examples inside [code] must remain literal.
    $str = gf_escapeAutotagsInCodeBlocks($str);

    // Replace autotags with random strings to prevent them from being parsed
    $markers = [];
    $simpleTags = [
		'[p]', '[/p]',
        '[b]', '[/b]',
        '[i]', '[/i]',
        '[u]', '[/u]',
        '[s]', '[/s]',
        '[img]', '[/img]',
        '[quote]', '[/quote]',
        '[list]', '[/list]',
        '[*]',
        '[url]', '[/url]',
        '[/size]',
        '[/color]',
        '[code]', '[/code]',
    ];

    if (preg_match_all('/\[[^\]]+?\]/', $str, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $content = strtolower($match[0]);

            if (in_array($content, $simpleTags)) {
                continue;
            } elseif ((strpos($content, '[img ') === 0) ||
                    (strpos($content, '[url=') === 0) ||
                    (strpos($content, '[size=') === 0) ||
                    (strpos($content, '[color=') === 0) ||
                    (strpos($content, '[list=') === 0) ||
                    (strpos($content, '[code=') === 0)) {
                continue;
            }

            $replace = '___' . bin2hex(random_bytes(10)) . '___';
            $markers[] = ['search' => $match[0], 'replace' => $replace];
            $str = str_replace($match[0], $replace, $str);
        }
    }

    $str = $bbcode->parse($str);

    // Restore original autotags
    if (count($markers) > 0) {
        foreach ($markers as $marker) {
            $str = str_replace($marker['replace'], $marker['search'], $str);
        }
    }
    
    // Replace autotags
    $str = PLG_replacetags($str);

    return $str;
}


function bbcode_oldpost($text) {
    global $CONF_FORUM;

    if ($CONF_FORUM['pre2.5_mode'] == true ) {
        $comment = str_replace("&#36;","$", $text);
        $comment = str_replace("<br />","\r",$comment);
        $comment = str_replace("<br>","\r",$comment);
        $comment = str_replace ( '&amp;', '&', $comment );
        $comment = str_replace ( '&#039;', '\'', $comment );
        $comment = str_replace ( '&quot;', '"', $comment );
        $comment = str_replace ( '&lt;', '<', $comment );
        $comment = str_replace ( '&gt;', '>', $comment );
        $comment = str_replace ( '<b>', '[b]', $comment );
        $comment = str_replace ( '</b>', '[/b]', $comment );
        $comment = str_replace ( '<i>', '[i]', $comment );
        $comment = str_replace ( '</i>', '[/i]', $comment );
        $comment = str_replace ( '<p>', '[p]', $comment );
        $comment = str_replace ( '</p>', '[/p]', $comment );
    } else {
        return $text;
    }
    return $comment;
}

function gf_formatOldPost($str,$postmode='html',$mode='') {
    global $CONF_FORUM;

    $oldPost = 0;

    if ( $CONF_FORUM['pre2.5_mode'] != true ) {
        return $str;
    }

    if (strstr($str,'<pre class="forumCode">') !== false)  $oldPost = 1;
    if (strstr($str,"[code]<code>") !== false) $oldPost = 1;
    if (strstr($str,"<pre>") !== false ) $oldPost = 1;

    if ( stristr($str,'[code') == false || stristr($str,'[code]<code>') == true) {
        if (strstr($str,"<pre>") !== false)  $oldPost = 1;
        $str = str_replace('<pre>','[code]',$str);
        $str = str_replace('</pre>','[/code]',$str);
    }
    $str = str_ireplace("[code]<code>",'[code]',$str);
    $str = str_ireplace("</code>[/code]",'[/code]',$str);
    $str = str_replace(array("<br />\r\n","<br />\n\r","<br />\r","<br />\n","<br>\r\n","<br>\n\r","<br>\r","<br>\n",), '<br' . XHTML . '>', $str );
    $str = preg_replace("/\[QUOTE\sBY=\s(.+?)\]/i","[QUOTE] Quote by $1:",$str);
    /* Reformat code blocks - version 2.3.3 and prior */
    $str = str_replace( '<pre class="forumCode">', '[code]', $str );
    $str = preg_replace("/\[QUOTE\sBY=(.+?)\]/i","[QUOTE] Quote by $1:",$str);

    $bbcode = new StringParser_BBCode ();
    $bbcode->setGlobalCaseSensitive (false);
    // It is impossible to include block level elements in a <p> element. Therefore I fix this.
    $bbcode->setParagraphHandlingParameters ("\n\n", "", "");

    if ( $postmode == 'text') {
        $bbcode->addParser (array ('block', 'inline', 'link', 'listitem'), 'bbcode_htmlspecialchars');
    }
    if ( $CONF_FORUM['use_glfilter'] == 1 && ($postmode == 'html' || $postmode == 'HTML') ) {
        $bbcode->addParser(array('block','inline','link','listitem'), 'gf_checkHTML');      // calls checkHTML on all text blocks
    }
    $bbcode->addParser(array('block','inline','link','list','listitem'), 'bbcode_oldpost');

    $bbcode->addCode ('code', 'simple_replace', null, array ('start_tag' => '[code]', 'end_tag' => '[/code]'),
                      'code', array ('listitem', 'block', 'inline', 'link'), array ());

    if ( $CONF_FORUM['use_censor'] ) {
        $str = COM_checkWords($str);
    }
    $str = $bbcode->parse ($str);

    // If we have identified an old post based on the checks above
    // it is possible that code blocks will have htmlencoded items
    // we need to reverse that ...
    if ( $oldPost ) {
        if ( strstr($str,"\\'") !== false ) {
            $str = stripslashes($str);
        }
        $str = str_replace("&#36;","$", $str);
        $str = str_replace("<br />","\r",$str);
        $str = str_replace("<br>","\r",$str);
        $str = str_replace ( '&amp;', '&', $str );
        $str = str_replace ( '&#039;', '\'', $str );
        $str = str_replace ( '&quot;', '"', $str );
        $str = str_replace ( '&lt;', '<', $str );
        $str = str_replace ( '&gt;', '>', $str );
    }

    $str = str_replace ( '&#92;', '\\',$str);

    return $str;
}

function gf_replacesmilie($str) {
    global $_CONF,$_TABLES,$CONF_FORUM;

    if ($CONF_FORUM['allow_smilies']) {
        if (function_exists('msg_showsmilies') AND $CONF_FORUM['use_smilies_plugin']) {
            $str = msg_replaceEmoticons($str);
        } else {
            $str = forum_xchsmilies($str);
        }
    }

    return $str;
}

/* Function gf_getImage - used to return the image URL for icons
 * The forum uses a number of icons and you may have a need to use a mixture of image types.
 * Enabling the $CONF_FORUM['autoimagetype'] feature will invoke a test that will first
 * check for an image of the type set in your themes function.php $_IMAGE_TYPE
 * If the icon of that image type is not found, then it will use an image of type
 * specified by the $CONF_FORUM['image_type_override'] setting.

 * Set $CONF_FORUM['autoimagetype'] to false in the plugins config.php to disable this feature and
 * only icons of type set by the themes $_IMAGE_TYPE setting will be used
*/
function gf_getImage($image,$directory='') {
    global $CONF_FORUM,$_IMAGE_TYPE;

    if ($directory != '')  {
        $fullImagePath = "{$CONF_FORUM['imgset_path']}/{$directory}/{$image}.{$_IMAGE_TYPE}";
    } else {
        $fullImagePath = "{$CONF_FORUM['imgset_path']}/{$image}.{$_IMAGE_TYPE}";
    }
    if ($CONF_FORUM['autoimagetype']) {
        $fullImageURL = "{$CONF_FORUM['imgset']}/";
        if ($directory != '')  $fullImageURL .= "{$directory}/";

        if (file_exists($fullImagePath)) {
            $fullImageURL .= "{$image}.{$_IMAGE_TYPE}";
        } else {
            $CONF_FORUM['image_type_override'] = ($_IMAGE_TYPE == 'gif') ? 'png' : 'gif'; // added
            $fullImageURL .= "{$image}.{$CONF_FORUM['image_type_override']}";
        }
    } else {
        $fullImageURL = "{$CONF_FORUM['imgset']}/{$image}.{$_IMAGE_TYPE}";
    }
    return $fullImageURL;
}

function alertMessage($message, $title = '', $prompt = '') {
    global $_CONF, $CONF_FORUM, $LANG_GF01, $LANG_GF02;

    $retval = '';

    if ($prompt == "0") {
        $title = ''; // No Prompt
    } elseif (empty($title)) {
    	$title = $LANG_GF01['MESSAGE'];
	}
    
    $alertmsg = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $alertmsg->set_file (array('alertmsg'=>'alertmsg.thtml'));

    $alertmsg->set_var ('imgset', $CONF_FORUM['imgset']);
    $alertmsg->set_var ('layout_url', $CONF_FORUM['layout_url']);
    $alertmsg->set_var ('alert_title', $title);
    $alertmsg->set_var ('alert_message', $message);
    if (empty($prompt)) {
        $alertmsg->set_var ('prompt', ''); // No Prompt
    } else {
        $alertmsg->set_var ('prompt', $prompt);
    }
    
    $alertmsg->parse ('output', 'alertmsg');
    $retval .= $alertmsg->finish ($alertmsg->get_var('output'));
    
    return $retval;
}


function BaseFooter($showbottom=true) {
    global $_USER,$_CONF,$LANG_GF02,$forum,$CONF_FORUM;

    $retval = '';
	
    // if (!$CONF_FORUM['registration_required'] OR !COM_isAnonUser()) {
	if ($CONF_FORUM['registration_required'] == 0 || ($CONF_FORUM['registration_required'] && SEC_hasRights('forum.user'))) {
        $footer = COM_newTemplate(CTL_plugin_templatePath('forum'));
        $footer->set_file (array ('footerblock'=>'footer/footer.thtml'));
        
        $footer->set_var ('imgset', $CONF_FORUM['imgset']);
        if ($forum == '') {
            $footer->set_var ('forum_time', f_forumtime() );
            if ($showbottom == "true") {
                $footer->set_var ('forum_legend', f_legend() );
                $footer->set_var ('forum_whosonline', f_whosonline() );
            }
          } else {
            $footer->set_var ('forum_time', f_forumtime() );
            if ($showbottom == "true") {
                $footer->set_var ('forum_legend', f_legend() );
                $footer->set_var ('forum_rules', f_forumrules() );
            }
        }
        $footer->set_var ('search_forum', f_forumsearch() );
        $footer->set_var ('select_forum', f_forumjump() );
        $footer->set_var('block_end', COM_endBlock());     
		$footer->parse ('output', 'footerblock');
		
        $retval .= $footer->finish($footer->get_var('output'));
    }
	
    return $retval;
}

function f_forumsearch() {
    global $_CONF,$_TABLES,$LANG_GF01,$LANG_GF02,$forum,$CONF_FORUM;

    $forum_search = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $forum_search->set_file (array ('forum_search'=>'forum_search.thtml'));
    $forum_search->set_var ('forum', $forum);
    if ($forum == "") {
        $forum_search->set_var ('search', $LANG_GF02['msg117']);
    } else {
        $forum_search->set_var ('search', $LANG_GF02['msg118']);
    }
    $forum_search->set_var ('jumpheading', $LANG_GF02['msg103']);
    $forum_search->set_var ('LANG_GO', $LANG_GF01['GO']);
    $forum_search->parse ('output', 'forum_search');
    return $forum_search->finish($forum_search->get_var('output'));
}


// Used by some admin pages as well
function f_userjump($type, $selected = '') {
    global $_CONF,$_TABLES,$LANG_GF02;
	
    $selectHTML = '';
	if ($type == 2) {
		// Users that have posted Forum and/or Topic Subscriptions
		$sql  = "SELECT u.uid, u.username FROM {$_TABLES['users']} u, {$_TABLES['forum_watch']} fw ";
		$sql .= "WHERE u.uid = fw.uid GROUP BY u.uid ORDER BY u.username";
	} else { // $type = 1
		// Users that have posted in the forum
		$sql  = "SELECT u.uid, u.username FROM {$_TABLES['users']} u, {$_TABLES['forum_topic']} ft ";
		$sql .= "WHERE u.uid = ft.uid GROUP BY u.uid ORDER BY u.username";
	}
    $memberlistsql = DB_query($sql);
    if ($selected == -1) {
        $selectHTML .= LB .'<option value="-1" selected="selected">' .$LANG_GF02['msg177']. '</option>';
    } else {
        $selectHTML .= LB .'<option value="-1">' .$LANG_GF02['msg177']. '</option>';
    }
    while($A = DB_fetchArray($memberlistsql)) {
        if ($A['uid'] == $selected) {
            $selectHTML .= LB .'<option value="' .$A['uid']. '" selected="selected">' .$A['username']. '</option>';
        } else {
            $selectHTML .= LB .'<option value="' .$A['uid']. '">' .$A['username']. '</option>';
        }
    }
    return $selectHTML;

}

function f_forumjump($action = '', $selected = 0, $OptionsOnly = false) {
    global $CONF_FORUM, $_CONF,$_TABLES,$LANG_GF01,$LANG_GF02;

    $selecthtml = '';
    $asql = DB_query("SELECT * FROM {$_TABLES['forum_categories']} ORDER BY cat_order ASC");
    while($A = DB_fetchArray($asql)) {
    	
        $catthtml = '<optgroup label="' .$A['cat_name']. '">' . LB;
        $formhtml = '';
        $bsql = DB_query("SELECT * FROM {$_TABLES['forum_forums']} WHERE forum_cat='{$A['id']}' ORDER BY forum_order ASC");
        while($B = DB_fetchArray($bsql)) {
            $groupname = DB_getItem($_TABLES['groups'],'grp_name',"grp_id='{$B['grp_id']}'");
            if (SEC_inGroup($B['grp_id'])) {
                if ($selected > 0 AND $selected == $B['forum_id']) {
                    $formhtml .= '<option value="' .$B['forum_id']. '" selected="selected">&#187;&nbsp;' .$B['forum_name']. '</option>' . LB;
                } else {
                    $formhtml .= '<option value="' .$B['forum_id']. '">&#187;&nbsp;' .$B['forum_name']. '</option>' . LB;
                }
            }
        }
        if (!empty($formhtml)) {
        	$selecthtml .= $catthtml . $formhtml . '</optgroup>' . LB;
		}
    }
	
	if ($OptionsOnly) {
		return $selecthtml;
	}
	
    $forum_jump = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $forum_jump->set_file (array ('forum_jump'=>'forum_jump.thtml'));
    $forum_jump->set_var ('LANG_msg103', $LANG_GF02['msg103']);
    $forum_jump->set_var ('LANG_msg106', $LANG_GF02['msg106']);
    $forum_jump->set_var ('jumpheading', $LANG_GF02['msg103']);
    $forum_jump->set_var ('imgset', $CONF_FORUM['imgset']);
    if ($action == '') {
        $forum_jump->set_var ('action', $_CONF['site_url'] . '/forum/index.php');
    } else {
        $forum_jump->set_var ('action', $action);
    }
    $forum_jump->set_var ('selecthtml', $selecthtml);
    $forum_jump->set_var ('LANG_GO', $LANG_GF01['GO']);
    $forum_jump->parse ('output', 'forum_jump');
    return $forum_jump->finish($forum_jump->get_var('output'));
}

function f_forumtime() {
    global $CONF_FORUM, $_CONF,$_TABLES,$LANG_GF01,$LANG_GF02,$forum;

    $forum_time = COM_newTemplate(CTL_plugin_templatePath('forum', 'footer'));
    $forum_time->set_file (array ('forum_time'=>'forum_time.thtml'));
    $timezone = COM_strftime('%Z');
	if (($_CONF['language'] === 'japanese_utf-8') &&
		(strpos(PHP_OS, 'WIN') === 0) &&
		is_callable('mb_convert_encoding')) {
		$timezone = mb_convert_encoding($timezone, COM_getCharset(), 'cp932');
	}
    $time = COM_strftime('%I:%M %p');
    $forum_time->set_var ('imgset', $CONF_FORUM['imgset']);
    $forum_time->set_var ('message', sprintf($LANG_GF02['msg121'],$timezone,$time));
    $forum_time->parse ('output', 'forum_time');
    return $forum_time->finish($forum_time->get_var('output'));
}

function f_legend() {
    global $CONF_FORUM,$forum,$_CONF,$LANG_GF01,$LANG_GF02;
    
    $forum_legend = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $forum_legend->set_file (array ('forum_legend'	=> 'footer/forum_legend.thtml',         
    								'forum_icons'   => 'forum_icons.thtml'
    ));
    $blocks = array('new_icon', 'quiet_icon', 'active_icon', 'normal_icon', 'normalnew_icon', 'sticky_icon', 'stickynew_icon', 'locked_icon', 'lockednew_icon');
    foreach ($blocks as $block) {
        $forum_legend->set_block('forum_icons', $block);
    }
    
    $forum_legend->set_var ('imgset', $CONF_FORUM['imgset']);

    if ($forum == '') {
        $forum_legend->set_var ('normal_msg', $LANG_GF02['msg194']);
        $forum_legend->set_var ('normalnew_msg', $LANG_GF02['msg108']);
        

        $forum_legend->parse ('normal_icon', 'quiet_icon');
        $forum_legend->parse ('normalnew_icon', 'active_icon');
        
        
        
        $forum_legend->parse ('viewnew_icon', 'new_icon');
        $forum_legend->set_var ('viewnew_msg', $LANG_GF02['msg112']);
        
        $forum_legend->set_var ('markread_icon','<img src="'.gf_getImage('allread').'" alt="' . $LANG_GF02['msg84'] .'" title="' .$LANG_GF02['msg84']. '"'. XHTML .'>');
        $forum_legend->set_var ('markread_msg', $LANG_GF02['msg84']);
    } else {
        $forum_legend->parse ('normal_icon', 'normal_icon');
        $forum_legend->parse ('normalnew_icon', 'normalnew_icon');
        $forum_legend->parse ('sticky_icon', 'sticky_icon');
        $forum_legend->parse ('stickynew_icon', 'stickynew_icon');
        $forum_legend->parse ('locked_icon', 'locked_icon');
        $forum_legend->parse ('lockednew_icon', 'lockednew_icon');
        
        $forum_legend->set_var ('normal_msg', $LANG_GF02['msg59']);
        $forum_legend->set_var ('normalnew_msg', $LANG_GF02['msg60']);
        $forum_legend->set_var ('sticky_msg',$LANG_GF02['msg61']);
        $forum_legend->set_var ('locked_msg', $LANG_GF02['msg114']);
        $forum_legend->set_var ('stickynew_msg', $LANG_GF02['msg115']);
        $forum_legend->set_var ('lockednew_msg', $LANG_GF02['msg116']);
    }

    $forum_legend->parse ('output', 'forum_legend');
    return $forum_legend->finish($forum_legend->get_var('output'));
}

function f_whosonline(){
    global $CONF_FORUM, $_CONF,$_TABLES,$LANG_GF02;

    $onlineusers = phpblock_whosonline();
    $forum_users = COM_newTemplate(CTL_plugin_templatePath('forum', 'footer'));
    $forum_users->set_file (array ('forum_users'=>'forum_users.thtml'));
    $forum_users->set_var ('LANG_msg07', $LANG_GF02['msg07']);
    $forum_users->set_var ('imgset', $CONF_FORUM['imgset']);
    $forum_users->set_var ('onlineusers', $onlineusers);
    $forum_users->parse ('output', 'forum_users');
    return $forum_users->finish($forum_users->get_var('output'));
}

function f_forumrules() {
    global $_CONF,$_USER,$LANG_GF01,$LANG_GF02,$CONF_FORUM;
    
    $forum_rules = COM_newTemplate(CTL_plugin_templatePath('forum'));
    $forum_rules->set_file (array ( 'forum_rules'	=> 'footer/forum_rules.thtml',         
    								'forum_icons'   => 'forum_icons.thtml'
    ));
    
    $blocks = array('status_yes', 'status_no');
    foreach ($blocks as $block) {
        $forum_rules->set_block('forum_icons', $block);
    }     

	// By this point permission of user is checked for viewing already
    if ( $CONF_FORUM['registered_to_post'] AND ($_USER['uid'] < 2 OR empty($_USER['uid'])) ) {
        $postperm_msg = $LANG_GF01['POST_PERM_MSG2'];
        $post_perm_image = "status_no";
    } else {
        $postperm_msg = $LANG_GF01['POST_PERM_MSG1'];
        $post_perm_image = "status_yes";
    }
    if ($CONF_FORUM['use_censor']) {
        $censor_perm_image = "status_yes";
    } else {
        $censor_perm_image = "status_no";
    }

    if ($CONF_FORUM['show_anonymous_posts']) {
        $anon_perm_image = "status_yes";
    } else {
        $anon_perm_image = "status_no";
    }
    
    $forum_rules->set_var ('imgset', $CONF_FORUM['imgset']);
    $forum_rules->set_var ('LANG_title', $LANG_GF02['msg101']);

    $forum_rules->set_var ('anonymous_msg', $LANG_GF01['ANON_PERM_MSG']);
    $forum_rules->parse ('anon_perm_image', $anon_perm_image);

    $forum_rules->set_var ('postingperm_msg',$postperm_msg);
    $forum_rules->parse ('post_perm_image', $post_perm_image);

    $forum_rules->set_var ('censor_msg', $LANG_GF01['CENSOR_PERM_MSG']);
    $forum_rules->parse ('censor_perm_image', $censor_perm_image);

    $forum_rules->parse ('output', 'forum_rules');
    return $forum_rules->finish($forum_rules->get_var('output'));

}

function gf_updateLastPost($forumid = 0, $topicparent = 0) {
    global $_TABLES;
    
	// Used to skip forum sync in gf_resyncforum when syncing each topic in forum
	if ($forumid > 0) {
		// Update forum record for: last_post_rec, topic_count, post_count
		
		// Get the last topic in this forum
		// Assuming that the forumid is the topicparent forum
		$query = DB_query("SELECT MAX(id) FROM {$_TABLES['forum_topic']} WHERE forum=$forumid");
		list($lastrecid) = DB_fetchArray($query);
		if ($lastrecid > 0) {
			// If topicparent not already specified set it now
			if ($topicparent == 0) {
				$topicparent = $lastrecid;
			}
			
			$topicCount = DB_count($_TABLES['forum_topic'], array('forum', 'pid'), array($forumid, 0));
			$postCount = DB_Count($_TABLES['forum_topic'],'forum',$forumid);
			 
			// Update the forum definition record to know the number of topics and number of posts
			DB_query("UPDATE {$_TABLES['forum_forums']} SET last_post_rec=$lastrecid, topic_count=$topicCount, post_count=$postCount WHERE forum_id=$forumid");		
		} else {
			// Forum has no posts
			DB_query("UPDATE {$_TABLES['forum_forums']} SET last_post_rec=0, topic_count=0, post_count=0 WHERE forum_id=$forumid");		
		}
	}
	
    if ($topicparent > 0) {
		// Update topic record for: lastupdated, last_reply_rec, numreplies
		
        $query = DB_query("SELECT MAX(id) FROM {$_TABLES['forum_topic']} WHERE pid=$topicparent");
        list($lastrecid) = DB_fetchArray($query);
		if ($lastrecid == NULL) {
			// Means just the original parent forum post and no replies
			$topicdatecreated = DB_getItem($_TABLES['forum_topic'],'date',"id=$topicparent");
			DB_query("UPDATE {$_TABLES['forum_topic']} SET last_reply_rec=0, lastupdated='$topicdatecreated' WHERE id=$topicparent");
		} else {
			$topicdatecreated = DB_getItem($_TABLES['forum_topic'],'date',"id=$lastrecid");
			DB_query("UPDATE {$_TABLES['forum_topic']}  SET last_reply_rec=$lastrecid, lastupdated='$topicdatecreated' WHERE id=$topicparent");
		}
		
		// Recalculate and Update the number of replies
		$numreplies = DB_Count($_TABLES['forum_topic'], "pid", $topicparent);
		DB_query("UPDATE {$_TABLES['forum_topic']} SET replies = $numreplies WHERE id=$topicparent");
	}
}

/**
 * Check is anonymous users can access and if not, regular user can access.
 * If $secure then will be a feature check and if user logged in (elseif before takes care of user security check for features as well)
 */
function forum_chkUsercanAccess($secure = false, $forum = '', $showtopic = '') {
    global $_CONF, $LANG_GF01, $LANG_GF02, $CONF_FORUM, $_USER, $_TABLES;

    $display = '';
	
	// Can anonymous users view posts
	if ($CONF_FORUM['registration_required'] && COM_isAnonUser()) {
    	$message = sprintf($LANG_GF01['loginreqview'], '<a href="' .$_CONF['site_url']. '/users.php?mode=new">', '<a href="' .$_CONF['site_url']. '/users.php">');
		$display = COM_showMessageText($message);
        $display = gf_createHTMLDocument($display);
        COM_output($display);
        exit;
	// Can regular users view posts
	} elseif ($CONF_FORUM['registration_required'] && !SEC_hasRights('forum.user')) {
		$display = COM_showMessageText($LANG_GF02['msg02'], $LANG_GF01['ACCESSERROR']);
        $display = gf_createHTMLDocument($display);
        COM_output($display);
        exit;
	// Login required to use this feature of the forum
    } elseif ($secure AND (empty($_USER['uid']) || $_USER['uid'] < 2)) {
		$message = sprintf($LANG_GF01['loginreqfeature'], '<a href="' .$_CONF['site_url']. '/users.php?mode=new">', '<a href="' .$_CONF['site_url']. '/users.php">');
		ForumHeader('', $forum, $showtopic, $display);
		$display .= COM_showMessageText($message, $LANG_GF01['ACCESSERROR']);
		$display = gf_createHTMLDocument($display);
		COM_output($display);
		exit;    	
    }

	// Check for forum and topic access if passed
    if (($forum !== '') || ($showtopic !== '')) { // Must not be blanks and number must be 0 or higher
		$grp_id = '';
        if ($showtopic !== '') {
            $forum_id = DB_getItem($_TABLES['forum_topic'],'forum',"id='$showtopic'");
			// Make sure if forum passed, that it matches actual forum of topic if also passed
			if (empty($forum_id) || (!empty($forum) && $forum != $forum_id)) {
				COM_handle404("{$_CONF['site_url']}/forum/index.php");
			}
            $grp_id = DB_getItem($_TABLES['forum_forums'],'grp_id',"forum_id='$forum_id'");
        } elseif ($forum !== '') {
            $grp_id = DB_getItem($_TABLES['forum_forums'],'grp_id',"forum_id='$forum'");
        }
        // Double check forum and/or topic exists
        if ($grp_id == '') {
            COM_handle404("{$_CONF['site_url']}/forum/index.php");
            exit;
        }        
        $groupname = DB_getItem($_TABLES['groups'],'grp_name',"grp_id='$grp_id'");
        if (!SEC_inGroup($groupname)) {
			ForumHeader('', $forum, $showtopic, $display);
			$display .= COM_showMessageText($LANG_GF02['msg77'], $LANG_GF01['ACCESSERROR']); // Access Forum Error
            $display = gf_createHTMLDocument($display);
            COM_output($display);            
            exit;
        }
    }	
}

/**
 * This function will replace the symbols in a forum post
 * with corresponding smilie images or the other way around.
 */
function forum_xchsmilies($message, $reverse = false) {
    global $_SMILIES;
    // Let the ForumSmilies class handle this
    return $_SMILIES->replace($message, $reverse);
}

?>
