// bbCode control by
// subBlue design
// www.subBlue.com

// Startup variables
var imageTag = false;
var theSelection = false;

// Check for Browser & Platform for PC & IE specific bits
// More details from: http://www.mozilla.org/docs/web-developer/sniffer/browser_type.html
var clientPC = navigator.userAgent.toLowerCase(); // Get client info
var clientVer = parseInt(navigator.appVersion); // Get browser version

var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
var is_nav = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1)
                && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1)
                && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
var is_moz = 0;

var is_win = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
var is_mac = (clientPC.indexOf("mac")!=-1);

// Define the bbCode tags
bbcode = new Array();
bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[quote]','[/quote]','[code]','[/code]','[list]','[/list]','[olist]','[/olist]','[img]','[/img]','[url]','[/url]');
imageTag = false;

// Shows the help messages in the helpline window
function helpline(help) {
    document.forumpost.helpbox.value = eval(help + "_help");
}


// Replacement for arrayname.length property
function getarraysize(thearray) {
    for (i = 0; i < thearray.length; i++) {
        if ((thearray[i] == "undefined") || (thearray[i] == "") || (thearray[i] == null))
            return i;
        }
    return thearray.length;
}

// Replacement for arrayname.push(value) not implemented in IE until version 5.5
// Appends element to the array
function arraypush(thearray,value) {
    thearray[ getarraysize(thearray) ] = value;
}

// Replacement for arrayname.pop() not implemented in IE until version 5.5
// Removes and returns the last element of an array
function arraypop(thearray) {
    thearraysize = getarraysize(thearray);
    retval = thearray[thearraysize - 1];
    delete thearray[thearraysize - 1];
    return retval;
}


function checkForm() {

    formErrors = false;

    if (document.forumpost.comment.value.length < 2) {
        formErrors = "You must enter a message when posting.";
    }

    if (formErrors) {
        alert(formErrors);
        return false;
    } else {
        bbstyle(-1);
        //formObj.preview.disabled = true;
        //formObj.submit.disabled = true;
        return true;
    }
}

function emoticon(text) {
    var txtarea = document.forumpost.comment;
    text = ' ' + text + ' ';
    if (txtarea.createTextRange && txtarea.caretPos) {
        var caretPos = txtarea.caretPos;
        caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? caretPos.text + text + ' ' : caretPos.text + text;
        txtarea.focus();
    } else {
        mozInsertCaret(txtarea, text);
        txtarea.focus();
    }
}

function bbfontstyle(bbopen, bbclose) {
    var txtarea = document.forumpost.comment;

    if ((clientVer >= 4) && is_ie && is_win) {
        theSelection = document.selection.createRange().text;
        if (!theSelection) {
            txtarea.value += bbopen + bbclose;
            txtarea.focus();
            return;
        }
        document.selection.createRange().text = bbopen + theSelection + bbclose;
        txtarea.focus();
        return;
    }
    else if (txtarea.selectionEnd && (txtarea.selectionEnd - txtarea.selectionStart > 0))
    {
        mozWrap(txtarea, bbopen, bbclose);
        return;
    }
    else
    {
        mozInsertCaret(txtarea, bbopen + bbclose);
        txtarea.focus();
    }
    storeCaret(txtarea);
}


function bbListSelection(ordered) {
    var txtarea = document.forumpost.comment;
    var start = typeof txtarea.selectionStart === 'number' ? txtarea.selectionStart : 0;
    var end = typeof txtarea.selectionEnd === 'number' ? txtarea.selectionEnd : 0;
    var selected = txtarea.value.substring(start, end);
    var openTag = ordered ? '[list=1]' : '[list]';
    var closeTag = '[/list]';
    var replacement;
    var caretOffset = 0;

    if (selected.length > 0) {
        var lines = selected.replace(/\r\n?/g, '\n').split('\n');
        var items = [];
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].replace(/^\s+|\s+$/g, '');
            if (line !== '') {
                items.push('[*]' + line);
            }
        }

        if (items.length === 0) {
            items.push('[*]');
        }

        replacement = openTag + '\n' + items.join('\n') + '\n' + closeTag;
        caretOffset = replacement.length;
    } else {
        replacement = openTag + '\n[*]\n' + closeTag;
        caretOffset = openTag.length + 4;
    }

    txtarea.value = txtarea.value.substring(0, start) + replacement + txtarea.value.substring(end);
    txtarea.focus();

    if (txtarea.setSelectionRange) {
        txtarea.setSelectionRange(start + caretOffset, start + caretOffset);
    }

    storeCaret(txtarea);
}

function bbstyle(bbnumber) {
    var txtarea = document.forumpost.comment;

    // A list is line-based: turn every selected non-empty line into one [*] item.
    if (bbnumber == 10) {
        bbListSelection(false);
        return;
    }
    var button;

    txtarea.focus();
    donotinsert = false;
    theSelection = false;
    bblast = 0;

    if (bbnumber == -1) { // Close all open tags & default button names
        while (bbcode[0]) {
            butnumber = arraypop(bbcode) - 1;
            mozInsertCaret(txtarea, bbtags[butnumber + 1]);
            button = eval('document.forumpost.addbbcode' + butnumber);
            button.classList.remove('uk-active');
        }
        imageTag = false; // All tags are closed including image tags :D
        txtarea.focus();
        return;
    }

    if ((clientVer >= 4) && is_ie && is_win)
    {
        theSelection = document.selection.createRange().text; // Get text selection
        if (theSelection) {
            // Add tags around selection
            document.selection.createRange().text = bbtags[bbnumber] + theSelection + bbtags[bbnumber+1];
            txtarea.focus();
            theSelection = '';
            return;
        }
    }
    else if (txtarea.selectionEnd && (txtarea.selectionEnd - txtarea.selectionStart > 0))
    {
        mozWrap(txtarea, bbtags[bbnumber], bbtags[bbnumber+1]);
        return;
    }

    // Find last occurance of an open tag the same as the one just clicked
    for (i = 0; i < bbcode.length; i++) {
        if (bbcode[i] == bbnumber+1) {
            bblast = i;
            donotinsert = true;
        }
    }

    if (donotinsert) {        // Close all open tags up to the one just clicked & default button names
        while (bbcode[bblast]) {
            butnumber = arraypop(bbcode) - 1;
            mozInsertCaret(txtarea, bbtags[butnumber + 1]);
            button = eval('document.forumpost.addbbcode' + butnumber);
            button.classList.remove('uk-active');
            imageTag = false;
        }
        txtarea.focus();
        return;
    } else { // Open tags

        if (imageTag && (bbnumber != 14)) {        // Close image tag before adding another
            txtarea.value += bbtags[15];
            lastValue = arraypop(bbcode) - 1;    // Remove the close image tag from the list
            document.forumpost.addbbcode14.value = "";    // Return button back to normal state
            imageTag = false;
        }

        // Open tag
        mozInsertCaret(txtarea, bbtags[bbnumber]);
        if ((bbnumber == 14) && (imageTag == false)) imageTag = 1; // Check to stop additional tags after an unclosed image tag
        arraypush(bbcode,bbnumber+1);
        button = eval('document.forumpost.addbbcode' + bbnumber);
        button.classList.add('uk-active');
        txtarea.focus();
        return;
    }
    storeCaret(txtarea);
}

// From http://www.massless.org/mozedit/
function mozWrap(txtarea, open, close)
{
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;
    var selEnd = txtarea.selectionEnd;
    if (selEnd == 1 || selEnd == 2)
        selEnd = selLength;

    var s1 = (txtarea.value).substring(0, selStart);
    var s2 = (txtarea.value).substring(selStart, selEnd)
    var s3 = (txtarea.value).substring(selEnd, selLength);
    txtarea.value = s1 + open + s2 + close + s3;

    txtarea.selectionStart = selEnd + open.length + close.length;
    txtarea.selectionEnd = txtarea.selectionStart;

    return;
}

function mozInsertCaret(txtarea, caret)
{
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;

    var s1 = (txtarea.value).substring(0, selStart);
    var s2 = (txtarea.value).substring(selStart, selLength);
    txtarea.value = s1 + caret + s2;

    txtarea.selectionStart = selStart + caret.length;
    txtarea.selectionEnd = txtarea.selectionStart;

    return;
}

// Insert at Claret position. Code from
// http://www.faqts.com/knowledge_base/view.phtml/aid/1052/fid/130
function storeCaret(textEl) {
    if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate();
}

var newwindow;
function poptastic(url)
{
    newwindow=window.open(url,'name','height=500,width=700,resizable=yes,scrollbars=yes');
    if (window.focus) {newwindow.focus()}
}


function AddRowsToTable() {
     var tbl = document.getElementById('tblforumfile');
     var lastRow = tbl.rows.length;

     // if there is no header row in the table, then iteration = lastRow + 1

     var iteration = lastRow;
     var row = tbl.insertRow(lastRow);
     
     var cellRight = row.insertCell(0);
     var el = document.createElement('input');
     el.setAttribute('type', 'FILE');
     el.setAttribute('name', 'mfile_forum[]');
     el.setAttribute('size', '40');
     cellRight.appendChild(el);
}

function RemoveRowFromTable() {
     var tbl = document.getElementById('tblforumfile');
     var lastRow = tbl.rows.length;
     if (lastRow > 0) tbl.deleteRow(lastRow - 1);
}

